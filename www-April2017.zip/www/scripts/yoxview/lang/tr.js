﻿// Translated by Ugur CELENK
{
    "Direction" : "ltr",
    "Close" : "Kapat",
    "Help" : "Yardım",
    "FirstImage" : "İlk resim",
    "LastImage" : "Son resim",
    "StartStopSlideShow" : "Başlat/Durdur slayt gösterisi",
    "Pause" : "Durdur",
    "Play" : "Başlat",
    "Prev" : "Önceki",
    "PinInfo" : "Pin info",
    "UnpinInfo" : "Unpin info",
    "Next" : "Sonraki",
    "PrevImage" : "Önceki resim",
    "NextImage" : "Sonraki resim",
    "Loading" : "Yükleniyor",
    "CloseHelp" : "Yardımı kapat",  
    "HelpText" : "Galeride klavye kullanarak geçiş yapabilirsiniz:<br/><br/>SOL/SAĞ YÖN TUŞLARI: Önceki/Sonraki<br/>BOŞLUK TUŞU: Sonraki<br/>ENTER: Slayt gösterisi Başlat/Durdur<br/>ESC: Galeriyi kapat<br />HOME/END: İlk/Son resim<br />H - Yardım paneli",
    "Slideshow" : "Başlat",
    "OriginalContext": "Orjinal içeriği göster"
}